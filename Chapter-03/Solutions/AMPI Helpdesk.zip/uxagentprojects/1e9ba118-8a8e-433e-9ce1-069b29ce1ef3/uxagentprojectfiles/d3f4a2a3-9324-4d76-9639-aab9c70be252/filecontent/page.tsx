import React, { useEffect, useMemo, useState } from "react";
import {
    Button,
    Spinner,
    Text,
    makeStyles,
    mergeClasses,
    tokens,
} from "@fluentui/react-components";
import {
    ArrowClockwiseRegular,
    CalendarTodayRegular,
    ChevronLeftRegular,
    ChevronRightRegular,
} from "@fluentui/react-icons";
import type {
    GeneratedComponentProps,
    QueryTableOptions,
    ReadableTableRow,
    apc_ticket,
} from "./RuntimeTypes";

type TicketRow = ReadableTableRow<apc_ticket> & {
    createdon?: string;
};

type TicketPriority = "Low" | "Medium" | "High" | "Unknown";

type CalendarDay = {
    date: Date;
    key: string;
    isCurrentMonth: boolean;
    isToday: boolean;
};

type CalendarState = {
    monthKey: string;
    tickets: TicketRow[];
    loading: boolean;
    error: string | null;
};

const winAny = window as unknown as Record<string, unknown>;
const DATAVERSE_FORMATTED_VALUE = "@OData.Community.Display.V1.FormattedValue";
const PRIORITY_VALUES: Record<number, TicketPriority> = {
    750120000: "Low",
    750120001: "Medium",
    750120002: "High",
};

const useStyles = makeStyles({
    root: {
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalM,
        height: "100%",
        minHeight: 0,
        overflowY: "auto",
        padding: tokens.spacingHorizontalL,
        boxSizing: "border-box",
        color: tokens.colorNeutralForeground1,
        backgroundColor: tokens.colorNeutralBackground1,
        "@media (max-width: 640px)": {
            padding: tokens.spacingHorizontalS,
        },
    },
    header: {
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "space-between",
        gap: tokens.spacingHorizontalL,
        flexWrap: "wrap",
    },
    heading: {
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalXS,
        minWidth: "12rem",
    },
    subtitle: {
        color: tokens.colorNeutralForeground2,
    },
    controls: {
        display: "flex",
        alignItems: "center",
        gap: tokens.spacingHorizontalXS,
        flexWrap: "wrap",
    },
    legend: {
        display: "flex",
        alignItems: "center",
        gap: tokens.spacingHorizontalM,
        flexWrap: "wrap",
        paddingBlock: tokens.spacingVerticalXS,
        color: tokens.colorNeutralForeground2,
    },
    legendItem: {
        display: "inline-flex",
        alignItems: "center",
        gap: tokens.spacingHorizontalXS,
        fontSize: tokens.fontSizeBase200,
    },
    legendSwatch: {
        width: "0.65rem",
        height: "0.65rem",
        borderRadius: tokens.borderRadiusSmall,
        flexShrink: 0,
    },
    lowSwatch: {
        backgroundColor: tokens.colorStatusSuccessBackground3,
        border: `1px solid ${tokens.colorStatusSuccessBorder1}`,
    },
    mediumSwatch: {
        backgroundColor: tokens.colorStatusWarningBackground3,
        border: `1px solid ${tokens.colorStatusWarningBorder1}`,
    },
    highSwatch: {
        backgroundColor: tokens.colorStatusDangerBackground3,
        border: `1px solid ${tokens.colorStatusDangerBorder1}`,
    },
    calendarFrame: {
        display: "flex",
        flexDirection: "column",
        flex: "1 1 auto",
        minHeight: "32rem",
        minWidth: 0,
        border: `1px solid ${tokens.colorNeutralStroke2}`,
        borderRadius: tokens.borderRadiusMedium,
        overflow: "hidden",
        backgroundColor: tokens.colorNeutralBackground1,
        "@media (max-width: 640px)": {
            minHeight: "28rem",
        },
    },
    weekdayRow: {
        display: "grid",
        gridTemplateColumns: "repeat(7, minmax(7rem, 1fr))",
        minWidth: "49rem",
        backgroundColor: tokens.colorNeutralBackground2,
        borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    },
    weekday: {
        padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalS}`,
        color: tokens.colorNeutralForeground2,
        fontSize: tokens.fontSizeBase200,
        fontWeight: tokens.fontWeightSemibold,
        textTransform: "uppercase",
        letterSpacing: "0",
    },
    calendarViewport: {
        flex: "1 1 auto",
        minHeight: 0,
        overflow: "auto",
    },
    calendarGrid: {
        display: "grid",
        gridTemplateColumns: "repeat(7, minmax(7rem, 1fr))",
        gridTemplateRows: "repeat(6, minmax(7rem, 1fr))",
        minWidth: "49rem",
        minHeight: "42rem",
    },
    dayCell: {
        display: "flex",
        flexDirection: "column",
        minWidth: 0,
        minHeight: 0,
        padding: tokens.spacingHorizontalS,
        borderRight: `1px solid ${tokens.colorNeutralStroke2}`,
        borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
        backgroundColor: tokens.colorNeutralBackground1,
        overflow: "hidden",
    },
    outsideMonth: {
        backgroundColor: tokens.colorNeutralBackground2,
    },
    todayCell: {
        backgroundColor: tokens.colorBrandBackground2,
    },
    dayHeader: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        minHeight: "1.5rem",
        marginBottom: tokens.spacingVerticalXS,
    },
    dayNumber: {
        color: tokens.colorNeutralForeground2,
        fontSize: tokens.fontSizeBase200,
        fontWeight: tokens.fontWeightSemibold,
    },
    todayNumber: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: "1.5rem",
        height: "1.5rem",
        borderRadius: tokens.borderRadiusCircular,
        color: tokens.colorNeutralForegroundOnBrand,
        backgroundColor: tokens.colorBrandBackground,
    },
    ticketList: {
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalXS,
        minHeight: 0,
        overflowY: "auto",
    },
    ticketButton: {
        display: "block",
        width: "100%",
        minWidth: 0,
        minHeight: "1.75rem",
        padding: `${tokens.spacingVerticalXS} ${tokens.spacingHorizontalS}`,
        border: "1px solid transparent",
        borderRadius: tokens.borderRadiusSmall,
        textAlign: "left",
        fontSize: tokens.fontSizeBase200,
        lineHeight: tokens.lineHeightBase200,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        justifyContent: "flex-start",
        transitionProperty: "background-color, border-color",
        transitionDuration: "120ms",
    },
    lowTicket: {
        color: tokens.colorStatusSuccessForeground1,
        backgroundColor: tokens.colorStatusSuccessBackground2,
        borderLeft: `3px solid ${tokens.colorStatusSuccessBorder1}`,
        ":hover": {
            backgroundColor: tokens.colorStatusSuccessBackground3,
        },
    },
    mediumTicket: {
        color: tokens.colorStatusWarningForeground1,
        backgroundColor: tokens.colorStatusWarningBackground2,
        borderLeft: `3px solid ${tokens.colorStatusWarningBorder1}`,
        ":hover": {
            backgroundColor: tokens.colorStatusWarningBackground3,
        },
    },
    highTicket: {
        color: tokens.colorStatusDangerForeground1,
        backgroundColor: tokens.colorStatusDangerBackground2,
        borderLeft: `3px solid ${tokens.colorStatusDangerBorder1}`,
        ":hover": {
            backgroundColor: tokens.colorStatusDangerBackground3,
        },
    },
    unknownTicket: {
        color: tokens.colorNeutralForeground1,
        backgroundColor: tokens.colorNeutralBackground3,
        borderLeft: `3px solid ${tokens.colorNeutralStrokeAccessible}`,
        ":hover": {
            backgroundColor: tokens.colorNeutralBackground4,
        },
    },
    loadingState: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: tokens.spacingHorizontalS,
        minHeight: "10rem",
        color: tokens.colorNeutralForeground2,
    },
    statusRow: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: tokens.spacingHorizontalM,
        flexWrap: "wrap",
        minHeight: "2rem",
    },
    statusMessage: {
        color: tokens.colorNeutralForeground2,
    },
    errorMessage: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: tokens.spacingHorizontalM,
        flexWrap: "wrap",
        padding: tokens.spacingHorizontalM,
        color: tokens.colorStatusDangerForeground1,
        backgroundColor: tokens.colorStatusDangerBackground2,
        border: `1px solid ${tokens.colorStatusDangerBorder1}`,
        borderRadius: tokens.borderRadiusMedium,
    },
});

function startOfMonth(value: Date): Date {
    return new Date(value.getFullYear(), value.getMonth(), 1);
}

function addMonths(value: Date, amount: number): Date {
    return new Date(value.getFullYear(), value.getMonth() + amount, 1);
}

function monthKey(value: Date): string {
    return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}`;
}

function dateKey(value: Date): string {
    return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
}

function buildCalendarDays(month: Date): CalendarDay[] {
    const firstOfMonth = startOfMonth(month);
    const firstCell = new Date(firstOfMonth);
    firstCell.setDate(firstCell.getDate() - firstOfMonth.getDay());
    const currentMonthKey = monthKey(firstOfMonth);
    const todayKey = dateKey(new Date());

    return Array.from({ length: 42 }, (_, index) => {
        const date = new Date(firstCell);
        date.setDate(firstCell.getDate() + index);
        return {
            date,
            key: dateKey(date),
            isCurrentMonth: monthKey(date) === currentMonthKey,
            isToday: dateKey(date) === todayKey,
        };
    });
}

function monthFilter(month: Date): string {
    const start = startOfMonth(month);
    const end = addMonths(start, 1);
    return `createdon ge ${start.toISOString()} and createdon lt ${end.toISOString()}`;
}

function getFormattedValue(ticket: TicketRow, field: string): string | undefined {
    const value = (ticket as unknown as Record<string, unknown>)[`${field}${DATAVERSE_FORMATTED_VALUE}`];
    return typeof value === "string" ? value : undefined;
}

function getPriority(ticket: TicketRow): TicketPriority {
    const formatted = getFormattedValue(ticket, "apc_ticketpriority");
    if (formatted) {
        const normalized = formatted.toLowerCase();
        if (normalized.includes("high")) return "High";
        if (normalized.includes("medium")) return "Medium";
        if (normalized.includes("low")) return "Low";
    }

    const raw = (ticket as unknown as Record<string, unknown>).apc_ticketpriority;
    if (typeof raw === "number" && PRIORITY_VALUES[raw]) return PRIORITY_VALUES[raw];
    if (typeof raw === "string") {
        const normalized = raw.toLowerCase();
        if (normalized.includes("high")) return "High";
        if (normalized.includes("medium")) return "Medium";
        if (normalized.includes("low")) return "Low";
        const numericValue = Number(raw);
        if (Number.isFinite(numericValue) && PRIORITY_VALUES[numericValue]) return PRIORITY_VALUES[numericValue];
    }

    return "Unknown";
}

function ticketTitle(ticket: TicketRow): string {
    return typeof ticket.apc_title === "string" && ticket.apc_title.trim()
        ? ticket.apc_title.trim()
        : "Untitled ticket";
}

function ticketCreatedDate(ticket: TicketRow): Date | null {
    const raw = (ticket as unknown as Record<string, unknown>).createdon;
    if (typeof raw !== "string" && typeof raw !== "number") return null;
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
}

function priorityText(priority: TicketPriority): string {
    return priority === "Unknown" ? "Priority not set" : `${priority} priority`;
}

async function queryTicketsForMonth(
    dataApi: GeneratedComponentProps["dataApi"],
    month: Date,
): Promise<TicketRow[]> {
    const query = {
        select: ["apc_ticketid", "apc_title", "apc_ticketpriority", "createdon"],
        filter: monthFilter(month),
        orderBy: "createdon asc",
        pageSize: 500,
    } as unknown as QueryTableOptions<apc_ticket>;
    let result = await dataApi.queryTable("apc_ticket", query);
    const rows = [...(result.rows as TicketRow[])];

    while (result.hasMoreRows && result.loadMoreRows) {
        result = await result.loadMoreRows();
        rows.push(...(result.rows as TicketRow[]));
    }

    return rows;
}

const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    const styles = useStyles();
    const dataReady = !!dataApi;
    const [displayedMonth, setDisplayedMonth] = useState(() => startOfMonth(new Date()));
    const [reloadKey, setReloadKey] = useState(0);
    const displayedMonthKey = monthKey(displayedMonth);
    const currentMonthKey = monthKey(new Date());
    const initialCache = winAny[`__genpage_ticketCalendar_${displayedMonthKey}_cache`] as TicketRow[] | undefined;
    const [data, setData] = useState<CalendarState>(() => ({
        monthKey: displayedMonthKey,
        tickets: initialCache ?? [],
        loading: initialCache === undefined,
        error: null,
    }));

    useEffect(() => {
        if (!dataReady) return;

        const cacheKey = `__genpage_ticketCalendar_${displayedMonthKey}_cache`;
        const inflightKey = `__genpage_ticketCalendar_${displayedMonthKey}_inflight`;
        const cached = winAny[cacheKey] as TicketRow[] | undefined;
        if (cached !== undefined) {
            if (data.monthKey !== displayedMonthKey || data.tickets !== cached || data.loading || data.error) {
                setData({ monthKey: displayedMonthKey, tickets: cached, loading: false, error: null });
            }
            return;
        }

        setData({ monthKey: displayedMonthKey, tickets: [], loading: true, error: null });
        let cancelled = false;
        let pending = winAny[inflightKey] as Promise<TicketRow[]> | undefined;
        if (!pending) {
            pending = queryTicketsForMonth(dataApi, displayedMonth)
                .then((rows) => {
                    winAny[cacheKey] = rows;
                    return rows;
                })
                .finally(() => {
                    if (winAny[inflightKey] === pending) delete winAny[inflightKey];
                });
            winAny[inflightKey] = pending;
        }

        pending
            .then((rows) => {
                if (!cancelled) setData({ monthKey: displayedMonthKey, tickets: rows, loading: false, error: null });
            })
            .catch((error: unknown) => {
                if (cancelled) return;
                console.error("Failed to load Ticket records", error);
                setData({ monthKey: displayedMonthKey, tickets: [], loading: false, error: "Unable to load tickets for this month." });
            });

        return () => {
            cancelled = true;
        };
        // Readiness and month only. The host supplies a new dataApi reference on renders.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dataReady, displayedMonthKey, reloadKey]);

    const calendarDays = useMemo(() => buildCalendarDays(displayedMonth), [displayedMonthKey]);
    const visibleTickets = data.monthKey === displayedMonthKey ? data.tickets : [];
    const ticketsByDay = useMemo(() => {
        const grouped: Record<string, TicketRow[]> = {};
        visibleTickets.forEach((ticket) => {
            const createdDate = ticketCreatedDate(ticket);
            if (!createdDate) return;
            const key = dateKey(createdDate);
            if (!grouped[key]) grouped[key] = [];
            grouped[key].push(ticket);
        });
        return grouped;
    }, [visibleTickets]);
    const isLoading = data.monthKey !== displayedMonthKey || data.loading;
    const priorityClasses: Record<TicketPriority, string> = {
        Low: styles.lowTicket,
        Medium: styles.mediumTicket,
        High: styles.highTicket,
        Unknown: styles.unknownTicket,
    };

    const retry = () => {
        const cacheKey = `__genpage_ticketCalendar_${displayedMonthKey}_cache`;
        const inflightKey = `__genpage_ticketCalendar_${displayedMonthKey}_inflight`;
        delete winAny[cacheKey];
        delete winAny[inflightKey];
        setReloadKey((value) => value + 1);
    };

    const openTicket = (ticket: TicketRow) => {
        if (!ticket.apc_ticketid) return;
        void window.Xrm.Navigation.navigateTo({
            pageType: "entityrecord",
            entityName: "apc_ticket",
            entityId: ticket.apc_ticketid,
        }).catch((error: unknown) => {
            console.error("Failed to open Ticket record", error);
        });
    };

    return (
        <div style={{ position: "relative", contain: "layout", height: "100%", overflow: "hidden" }}>
            <div className={styles.root}>
                <header className={styles.header}>
                    <div className={styles.heading}>
                        <Text as="h1" size={700} weight="semibold">
                            Ticket calendar
                        </Text>
                        <Text className={styles.subtitle}>
                            {displayedMonth.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
                        </Text>
                    </div>
                    <nav className={styles.controls} aria-label="Calendar navigation">
                        <Button
                            appearance="subtle"
                            icon={<ChevronLeftRegular />}
                            onClick={() => setDisplayedMonth((value) => addMonths(value, -1))}
                            aria-label="Previous month"
                        >
                            Previous
                        </Button>
                        <Button
                            appearance="secondary"
                            icon={<CalendarTodayRegular />}
                            onClick={() => setDisplayedMonth(startOfMonth(new Date()))}
                            disabled={displayedMonthKey === currentMonthKey}
                        >
                            Today
                        </Button>
                        <Button
                            appearance="subtle"
                            icon={<ChevronRightRegular />}
                            onClick={() => setDisplayedMonth((value) => addMonths(value, 1))}
                            aria-label="Next month"
                        >
                            Next
                        </Button>
                    </nav>
                </header>

                <div className={styles.legend} aria-label="Ticket priority legend">
                    <Text weight="semibold" size={300}>Priority</Text>
                    <span className={styles.legendItem}><span className={mergeClasses(styles.legendSwatch, styles.lowSwatch)} />Low</span>
                    <span className={styles.legendItem}><span className={mergeClasses(styles.legendSwatch, styles.mediumSwatch)} />Medium</span>
                    <span className={styles.legendItem}><span className={mergeClasses(styles.legendSwatch, styles.highSwatch)} />High</span>
                </div>

                {data.error && (
                    <div className={styles.errorMessage} role="alert">
                        <Text>{data.error}</Text>
                        <Button appearance="secondary" icon={<ArrowClockwiseRegular />} onClick={retry}>
                            Try again
                        </Button>
                    </div>
                )}

                <div className={styles.statusRow} aria-live="polite">
                    {isLoading && <Text className={styles.statusMessage}>Loading tickets...</Text>}
                    {!isLoading && !data.error && visibleTickets.length === 0 && (
                        <Text className={styles.statusMessage}>No tickets were created in this month.</Text>
                    )}
                    {!isLoading && !data.error && visibleTickets.length > 0 && (
                        <Text className={styles.statusMessage}>
                            {visibleTickets.length} {visibleTickets.length === 1 ? "ticket" : "tickets"}
                        </Text>
                    )}
                </div>

                <section className={styles.calendarFrame} aria-label={`${displayedMonth.toLocaleDateString(undefined, { month: "long", year: "numeric" })} Ticket calendar`}>
                    <div className={styles.weekdayRow} role="row">
                        {["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].map((weekday) => (
                            <div className={styles.weekday} role="columnheader" key={weekday}>
                                {weekday}
                            </div>
                        ))}
                    </div>
                    <div className={styles.calendarViewport}>
                        {isLoading ? (
                            <div className={styles.loadingState} role="status">
                                <Spinner size="small" label="Loading tickets" />
                            </div>
                        ) : (
                            <div className={styles.calendarGrid} role="grid" aria-label="Ticket days">
                                {calendarDays.map((day) => {
                                    const tickets = ticketsByDay[day.key] ?? [];
                                    return (
                                        <div
                                            className={mergeClasses(
                                                styles.dayCell,
                                                !day.isCurrentMonth && styles.outsideMonth,
                                                day.isToday && styles.todayCell,
                                            )}
                                            role="gridcell"
                                            aria-label={`${day.date.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" })}, ${tickets.length} ${tickets.length === 1 ? "ticket" : "tickets"}`}
                                            key={day.key}
                                        >
                                            <div className={styles.dayHeader}>
                                                <Text className={day.isToday ? styles.todayNumber : styles.dayNumber}>
                                                    {day.date.getDate()}
                                                </Text>
                                            </div>
                                            <div className={styles.ticketList}>
                                                {tickets.map((ticket) => {
                                                    const priority = getPriority(ticket);
                                                    const title = ticketTitle(ticket);
                                                    const createdDate = ticketCreatedDate(ticket);
                                                    const createdLabel = createdDate
                                                        ? createdDate.toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })
                                                        : "an unknown date";
                                                    return (
                                                        <Button
                                                            key={ticket.apc_ticketid}
                                                            className={mergeClasses(styles.ticketButton, priorityClasses[priority])}
                                                            appearance="transparent"
                                                            size="small"
                                                            onClick={() => openTicket(ticket)}
                                                            title={`${title} - ${priorityText(priority)}`}
                                                            aria-label={`${title}, ${priorityText(priority)}, created ${createdLabel}`}
                                                        >
                                                            {title}
                                                        </Button>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default GeneratedComponent;
