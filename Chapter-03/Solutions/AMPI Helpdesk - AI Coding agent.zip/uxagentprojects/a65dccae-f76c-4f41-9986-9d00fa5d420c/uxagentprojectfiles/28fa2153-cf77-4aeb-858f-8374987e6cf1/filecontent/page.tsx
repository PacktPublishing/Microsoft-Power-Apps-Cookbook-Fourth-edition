import { useEffect, useRef, useState } from 'react';
import type { GeneratedComponentProps, ReadableTableRow, account, new_project, new_ticket } from './RuntimeTypes';
import {
    Button,
    Card,
    CardHeader,
    SearchBox,
    Spinner,
    Text,
    makeStyles,
    tokens,
} from '@fluentui/react-components';
import { SearchRegular } from '@fluentui/react-icons';
import * as d3 from 'd3';

type TicketRecord = ReadableTableRow<new_ticket>;
type ProjectRecord = ReadableTableRow<new_project>;
type AccountRecord = ReadableTableRow<account>;
type OverviewRows = {
    tickets: TicketRecord[];
    projects: ProjectRecord[];
    accounts: AccountRecord[];
};
type ChoiceDatum = { label: string; value: number };

type PageProps = GeneratedComponentProps & {
    pageInput?: { data?: Record<string, unknown> };
};

const CACHE_KEY = '__ppAmpiHelpdeskOverviewCache';
const INFLIGHT_KEY = '__ppAmpiHelpdeskOverviewInflight';
const winAny = window as unknown as Record<string, unknown>;

const statusLabels: Record<string, string> = {
    '100000000': 'New',
    '100000001': 'Pending',
    '100000002': 'Resolved',
    '100000003': 'Closed',
};
const priorityLabels: Record<string, string> = {
    '100000000': 'Low',
    '100000001': 'Medium',
    '100000002': 'High',
};

const useStyles = makeStyles({
    root: {
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalL,
        padding: tokens.spacingHorizontalXL,
        width: '100%',
        minHeight: '100%',
        boxSizing: 'border-box',
        position: 'relative',
        contain: 'layout',
        backgroundColor: tokens.colorNeutralBackground2,
    },
    header: {
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        gap: tokens.spacingHorizontalL,
        flexWrap: 'wrap',
    },
    titleBlock: {
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalXS,
    },
    eyebrow: {
        color: tokens.colorBrandForeground1,
        fontWeight: tokens.fontWeightSemibold,
        textTransform: 'uppercase',
        letterSpacing: tokens.fontLetterSpacingBase200,
    },
    subtitle: {
        color: tokens.colorNeutralForeground2,
        maxWidth: '720px',
    },
    headerActions: {
        display: 'flex',
        alignItems: 'center',
        gap: tokens.spacingHorizontalS,
        flexWrap: 'wrap',
    },
    metrics: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
        gap: tokens.spacingHorizontalM,
        '@media (max-width: 720px)': {
            gridTemplateColumns: '1fr',
        },
    },
    metricCard: {
        display: 'flex',
        flexDirection: 'column',
        gap: tokens.spacingVerticalXS,
        padding: tokens.spacingHorizontalL,
        minWidth: 0,
    },
    metricLabel: {
        color: tokens.colorNeutralForeground2,
    },
    metricValue: {
        color: tokens.colorNeutralForeground1,
        fontSize: tokens.fontSizeHero800,
        fontWeight: tokens.fontWeightSemibold,
        lineHeight: tokens.lineHeightHero800,
    },
    metricHint: {
        color: tokens.colorNeutralForeground3,
    },
    chartGrid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
        gap: tokens.spacingHorizontalL,
        '@media (max-width: 900px)': {
            gridTemplateColumns: '1fr',
        },
    },
    chartCard: {
        minWidth: 0,
        overflow: 'hidden',
    },
    chart: {
        width: '100%',
        height: '230px',
        display: 'block',
    },
    chartFallback: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '230px',
        color: tokens.colorNeutralForeground3,
    },
    pendingCard: {
        minWidth: 0,
        overflow: 'hidden',
    },
    listToolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: tokens.spacingHorizontalM,
        flexWrap: 'wrap',
        padding: `0 ${tokens.spacingHorizontalL} ${tokens.spacingVerticalM}`,
    },
    listCount: {
        color: tokens.colorNeutralForeground2,
    },
    tableWrap: {
        overflowX: 'auto',
    },
    table: {
        width: '100%',
        borderCollapse: 'collapse',
        minWidth: '680px',
    },
    tableHeader: {
        color: tokens.colorNeutralForeground2,
        fontSize: tokens.fontSizeBase200,
        fontWeight: tokens.fontWeightSemibold,
        textAlign: 'left',
        padding: `${tokens.spacingVerticalS} ${tokens.spacingHorizontalL}`,
        borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
        borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
        whiteSpace: 'nowrap',
    },
    tableCell: {
        color: tokens.colorNeutralForeground1,
        padding: `${tokens.spacingVerticalM} ${tokens.spacingHorizontalL}`,
        borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
        verticalAlign: 'top',
    },
    ticketTitle: {
        fontWeight: tokens.fontWeightSemibold,
    },
    secondary: {
        color: tokens.colorNeutralForeground2,
        fontSize: tokens.fontSizeBase200,
    },
    priorityHigh: {
        color: tokens.colorPaletteRedForeground1,
        fontWeight: tokens.fontWeightSemibold,
    },
    priorityMedium: {
        color: tokens.colorPaletteOrangeForeground1,
        fontWeight: tokens.fontWeightSemibold,
    },
    priorityLow: {
        color: tokens.colorNeutralForeground2,
    },
    status: {
        color: tokens.colorBrandForeground1,
        fontWeight: tokens.fontWeightSemibold,
    },
    empty: {
        padding: tokens.spacingHorizontalL,
        color: tokens.colorNeutralForeground2,
    },
    error: {
        padding: tokens.spacingHorizontalM,
        color: tokens.colorStatusDangerForeground2,
        backgroundColor: tokens.colorStatusDangerBackground2,
        borderRadius: tokens.borderRadiusMedium,
    },
    loading: {
        display: 'flex',
        justifyContent: 'center',
        padding: tokens.spacingVerticalXXL,
    },
});

function choiceLabel(row: Record<string, unknown>, field: string, labels: Record<string, string>): string {
    const formatted = row[`${field}@OData.Community.Display.V1.FormattedValue`];
    if (typeof formatted === 'string' && formatted.length > 0) return formatted;
    const raw = row[field];
    if (typeof raw === 'number') return labels[String(raw)] ?? String(raw);
    if (typeof raw === 'string') return labels[raw] ?? raw;
    return 'Unknown';
}

function priorityClass(priority: string, styles: ReturnType<typeof useStyles>): string {
    if (priority === 'High') return styles.priorityHigh;
    if (priority === 'Medium') return styles.priorityMedium;
    return styles.priorityLow;
}

function buildChoiceData(rows: TicketRecord[], field: string, labels: string[], labelMap: Record<string, string>): ChoiceDatum[] {
    return labels.map((label) => ({
        label,
        value: rows.filter((row) => choiceLabel(row as unknown as Record<string, unknown>, field, labelMap) === label).length,
    }));
}

const DonutChart = (props: { data: ChoiceDatum[]; label: string; className: string }) => {
    const svgRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        const node = svgRef.current;
        if (!node) return;
        const svg = d3.select(node);
        svg.selectAll('*').remove();
        const width = 640;
        const height = 230;
        const radius = Math.min(width, height) / 2 - 28;
        const group = svg.append('g').attr('transform', `translate(${width / 2},${height / 2})`);
        const palette = [tokens.colorBrandBackground, tokens.colorPaletteBlueBorderActive, tokens.colorPaletteTealBorderActive];
        const pie = d3.pie<ChoiceDatum>().value((item) => item.value).sort(null);
        const arc = d3.arc<d3.PieArcDatum<ChoiceDatum>>().innerRadius(radius * 0.56).outerRadius(radius);
        const total = d3.sum(props.data, (item) => item.value);

        group.selectAll('path')
            .data(pie(props.data))
            .join('path')
            .attr('d', arc)
            .attr('fill', (_, index) => palette[index % palette.length])
            .attr('stroke', tokens.colorNeutralBackground1)
            .attr('stroke-width', 3);

        group.append('text')
            .attr('text-anchor', 'middle')
            .attr('dy', '-0.1em')
            .attr('fill', tokens.colorNeutralForeground1)
            .attr('font-size', '30px')
            .attr('font-weight', '600')
            .text(total);
        group.append('text')
            .attr('text-anchor', 'middle')
            .attr('dy', '1.5em')
            .attr('fill', tokens.colorNeutralForeground2)
            .attr('font-size', '14px')
            .text('tickets');

        const legend = svg.append('g').attr('transform', 'translate(430, 48)');
        props.data.forEach((item, index) => {
            const row = legend.append('g').attr('transform', `translate(0, ${index * 34})`);
            row.append('rect').attr('width', 12).attr('height', 12).attr('rx', 2).attr('fill', palette[index % palette.length]);
            row.append('text').attr('x', 22).attr('y', 11).attr('fill', tokens.colorNeutralForeground1).attr('font-size', '14px').text(`${item.label} (${item.value})`);
        });
    }, [props.data]);

    return <svg ref={svgRef} className={props.className} role="img" aria-label={props.label} viewBox="0 0 640 230" />;
};

const ColumnChart = (props: { data: ChoiceDatum[]; label: string; className: string }) => {
    const svgRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        const node = svgRef.current;
        if (!node) return;
        const svg = d3.select(node);
        svg.selectAll('*').remove();
        const width = 640;
        const height = 230;
        const margin = { top: 18, right: 20, bottom: 48, left: 42 };
        const innerWidth = width - margin.left - margin.right;
        const innerHeight = height - margin.top - margin.bottom;
        const group = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const maxValue = Math.max(1, d3.max(props.data, (item) => item.value) ?? 1);
        const x = d3.scaleBand<string>().domain(props.data.map((item) => item.label)).range([0, innerWidth]).padding(0.28);
        const y = d3.scaleLinear().domain([0, maxValue]).nice().range([innerHeight, 0]);

        group.append('g').attr('transform', `translate(0,${innerHeight})`).call(d3.axisBottom(x)).attr('color', tokens.colorNeutralForeground2);
        group.append('g').call(d3.axisLeft(y).ticks(Math.min(4, maxValue))).attr('color', tokens.colorNeutralForeground2);
        group.selectAll('rect')
            .data(props.data)
            .join('rect')
            .attr('x', (item) => x(item.label) ?? 0)
            .attr('y', (item) => y(item.value))
            .attr('width', x.bandwidth())
            .attr('height', (item) => innerHeight - y(item.value))
            .attr('rx', 4)
            .attr('fill', tokens.colorBrandBackground);
        group.selectAll('text.value')
            .data(props.data)
            .join('text')
            .attr('class', 'value')
            .attr('x', (item) => (x(item.label) ?? 0) + x.bandwidth() / 2)
            .attr('y', (item) => y(item.value) - 7)
            .attr('text-anchor', 'middle')
            .attr('fill', tokens.colorNeutralForeground1)
            .attr('font-size', '13px')
            .attr('font-weight', '600')
            .text((item) => item.value);
    }, [props.data]);

    return <svg ref={svgRef} className={props.className} role="img" aria-label={props.label} viewBox="0 0 640 230" />;
};

const GeneratedComponent = (props: PageProps) => {
    const { dataApi, pageInput } = props;
    void pageInput;
    const styles = useStyles();
    const [reloadKey, setReloadKey] = useState(0);
    const [search, setSearch] = useState('');
    const [data, setData] = useState<OverviewRows & { loading: boolean; error: string | null }>(() => {
        const cached = winAny[CACHE_KEY] as OverviewRows | undefined;
        return {
            tickets: cached?.tickets ?? [],
            projects: cached?.projects ?? [],
            accounts: cached?.accounts ?? [],
            loading: cached === undefined,
            error: null,
        };
    });
    const dataReady = !!dataApi;

    useEffect(() => {
        if (!dataReady || !dataApi) return;
        const cached = winAny[CACHE_KEY] as OverviewRows | undefined;
        if (cached) {
            if (data.tickets !== cached.tickets || data.projects !== cached.projects || data.accounts !== cached.accounts) {
                setData({ ...cached, loading: false, error: null });
            }
            return;
        }
        let cancelled = false;
        let inflight = winAny[INFLIGHT_KEY] as Promise<OverviewRows> | undefined;
        if (!inflight) {
            const ticketRequest = dataApi.queryTable('new_ticket', {
                select: ['new_ticketid', 'new_title', 'new_ticketpriority', 'new_ticketstatus', '_new_projectid_value'],
                orderBy: 'new_title asc',
                pageSize: 200,
            }) as Promise<{ rows: TicketRecord[] }>;
            const projectRequest = dataApi.queryTable('new_project', {
                select: ['new_projectid', 'new_title', '_new_accountid_value'],
                orderBy: 'new_title asc',
                pageSize: 100,
            }) as Promise<{ rows: ProjectRecord[] }>;
            const accountRequest = dataApi.queryTable('account', {
                select: ['accountid', 'name'],
                orderBy: 'name asc',
                pageSize: 100,
            }) as Promise<{ rows: AccountRecord[] }>;
            inflight = Promise.all([ticketRequest, projectRequest, accountRequest])
                .then(([tickets, projects, accounts]) => {
                    const rows = { tickets: tickets.rows, projects: projects.rows, accounts: accounts.rows };
                    winAny[CACHE_KEY] = rows;
                    return rows;
                })
                .finally(() => {
                    if (winAny[INFLIGHT_KEY] === inflight) delete winAny[INFLIGHT_KEY];
                });
            winAny[INFLIGHT_KEY] = inflight;
        }
        inflight
            .then((rows) => {
                if (!cancelled) setData({ ...rows, loading: false, error: null });
            })
            .catch(() => {
                if (!cancelled) setData({ tickets: [], projects: [], accounts: [], loading: false, error: 'Unable to load the helpdesk overview.' });
            });
        return () => {
            cancelled = true;
        };
    }, [dataReady, reloadKey]);

    const projectNames = new Map(data.projects.map((project) => [project.new_projectid, project.new_title]));
    const accountNames = new Map(data.accounts.map((account) => [account.accountid, account.name]));
    const pendingTickets = data.tickets
        .filter((ticket) => {
            const label = choiceLabel(ticket as unknown as Record<string, unknown>, 'new_ticketstatus', statusLabels);
            return label !== 'Resolved' && label !== 'Closed';
        })
        .filter((ticket) => {
            if (!search.trim()) return true;
            const term = search.trim().toLowerCase();
            const row = ticket as unknown as Record<string, unknown>;
            const projectId = String(row._new_projectid_value ?? '');
            const project = projectNames.get(projectId) ?? '';
            const priority = choiceLabel(row, 'new_ticketpriority', priorityLabels);
            const status = choiceLabel(row, 'new_ticketstatus', statusLabels);
            return [ticket.new_title, project, priority, status].some((value) => String(value ?? '').toLowerCase().includes(term));
        });
    const priorityData = buildChoiceData(data.tickets, 'new_ticketpriority', ['Low', 'Medium', 'High'], priorityLabels);
    const statusData = buildChoiceData(data.tickets, 'new_ticketstatus', ['New', 'Pending', 'Resolved', 'Closed'], statusLabels);
    const urgentCount = data.tickets.filter((ticket) => choiceLabel(ticket as unknown as Record<string, unknown>, 'new_ticketpriority', priorityLabels) === 'High').length;
    const activeProjectCount = data.projects.length;
    const customerCount = data.accounts.length;

    if (data.loading) {
        return (
            <div className={styles.root}>
                <div className={styles.loading}>
                    <Spinner label="Loading helpdesk overview" labelPosition="below" />
                </div>
            </div>
        );
    }

    return (
        <main className={styles.root} aria-labelledby="overview-title">
            <header className={styles.header}>
                <div className={styles.titleBlock}>
                    <Text className={styles.eyebrow} size={200}>AMPI helpdesk</Text>
                    <Text id="overview-title" as="h1" size={800} weight="semibold">Open work overview</Text>
                    <Text className={styles.subtitle}>A live view of pending tickets, priority pressure, and work across customer projects.</Text>
                </div>
                <div className={styles.headerActions}>
                    <SearchBox
                        value={search}
                        onChange={(_, change) => setSearch(change.value)}
                        placeholder="Search pending tickets"
                        contentBefore={<SearchRegular />}
                        aria-label="Search pending tickets"
                    />
                    <Button
                        appearance="secondary"
                        onClick={() => {
                            delete winAny[CACHE_KEY];
                            delete winAny[INFLIGHT_KEY];
                            setReloadKey((value) => value + 1);
                        }}
                    >
                        Refresh
                    </Button>
                </div>
            </header>

            {data.error && <div className={styles.error} role="alert">{data.error}</div>}

            <section className={styles.metrics} aria-label="Overview metrics">
                <Card className={styles.metricCard}>
                    <Text className={styles.metricLabel}>Pending tickets</Text>
                    <Text className={styles.metricValue}>{data.tickets.filter((ticket) => choiceLabel(ticket as unknown as Record<string, unknown>, 'new_ticketstatus', statusLabels) !== 'Resolved' && choiceLabel(ticket as unknown as Record<string, unknown>, 'new_ticketstatus', statusLabels) !== 'Closed').length}</Text>
                    <Text className={styles.metricHint}>Work still in New or Pending status</Text>
                </Card>
                <Card className={styles.metricCard}>
                    <Text className={styles.metricLabel}>High priority</Text>
                    <Text className={styles.metricValue}>{urgentCount}</Text>
                    <Text className={styles.metricHint}>Tickets needing the closest attention</Text>
                </Card>
                <Card className={styles.metricCard}>
                    <Text className={styles.metricLabel}>Active projects</Text>
                    <Text className={styles.metricValue}>{activeProjectCount}</Text>
                    <Text className={styles.metricHint}>{customerCount} customer accounts in scope</Text>
                </Card>
            </section>

            <section className={styles.chartGrid} aria-label="Ticket charts">
                <Card className={styles.chartCard}>
                    <CardHeader header={<Text weight="semibold">Tickets by priority</Text>} description="Current workload grouped by urgency" />
                    {data.tickets.length > 0 ? <DonutChart data={priorityData} label="Tickets by priority" className={styles.chart} /> : <div className={styles.chartFallback}>No ticket data available.</div>}
                </Card>
                <Card className={styles.chartCard}>
                    <CardHeader header={<Text weight="semibold">Tickets by status</Text>} description="Distribution across the support lifecycle" />
                    {data.tickets.length > 0 ? <ColumnChart data={statusData} label="Tickets by status" className={styles.chart} /> : <div className={styles.chartFallback}>No ticket data available.</div>}
                </Card>
            </section>

            <Card className={styles.pendingCard}>
                <CardHeader header={<Text weight="semibold">Pending tickets</Text>} description="Newest open work across every project" />
                <div className={styles.listToolbar}>
                    <Text className={styles.listCount}>{pendingTickets.length} ticket{pendingTickets.length === 1 ? '' : 's'} shown</Text>
                </div>
                {pendingTickets.length === 0 ? (
                    <div className={styles.empty}>No pending tickets match the current search.</div>
                ) : (
                    <div className={styles.tableWrap}>
                        <table className={styles.table} aria-label="Pending tickets">
                            <thead>
                                <tr>
                                    <th className={styles.tableHeader}>Ticket</th>
                                    <th className={styles.tableHeader}>Project</th>
                                    <th className={styles.tableHeader}>Customer</th>
                                    <th className={styles.tableHeader}>Priority</th>
                                    <th className={styles.tableHeader}>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {pendingTickets.map((ticket) => {
                                    const row = ticket as unknown as Record<string, unknown>;
                                    const projectId = String(row._new_projectid_value ?? '');
                                    const project = data.projects.find((item) => item.new_projectid === projectId);
                                    const projectName = projectNames.get(projectId) ?? 'Unassigned';
                                    const customerName = project ? accountNames.get(String((project as unknown as Record<string, unknown>)._new_accountid_value ?? '')) ?? 'Unknown account' : 'Unknown account';
                                    const priority = choiceLabel(row, 'new_ticketpriority', priorityLabels);
                                    const status = choiceLabel(row, 'new_ticketstatus', statusLabels);
                                    return (
                                        <tr key={ticket.new_ticketid}>
                                            <td className={styles.tableCell}>
                                                <div className={styles.ticketTitle}>{ticket.new_title}</div>
                                                <div className={styles.secondary}>Ticket record</div>
                                            </td>
                                            <td className={styles.tableCell}>{projectName}</td>
                                            <td className={styles.tableCell}>{customerName}</td>
                                            <td className={`${styles.tableCell} ${priorityClass(priority, styles)}`}>{priority}</td>
                                            <td className={`${styles.tableCell} ${styles.status}`}>{status}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </Card>
        </main>
    );
};

export default GeneratedComponent;

